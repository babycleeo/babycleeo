// api.js

const BASE_URL = 'https://psw-server.onrender.com';
const PUBLIC_ID = '28327'; // Substituir pelo  número de aluno
const PRIVATE_ID = 'kcmla'; // código privado

export const getUsers = async () => {
  try {
    const response = await fetch(`${BASE_URL}/users/`);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Erro ao obter lista de utilizadores:', error);
    throw error;
  }
};

export const getUserHeroes = async () => {
  try {
    const response = await fetch(`${BASE_URL}/users/${PUBLIC_ID}`);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Erro ao obter lista de super-heróis de um utilizador específico:', error);
    throw error;
  }
};

export const getUserTopHeroes = async () => {
  try {
    const response = await fetch(`${BASE_URL}/users/${PUBLIC_ID}/top`);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Erro ao obter top-3 da lista de super-heróis de um utilizador específico:', error);
    throw error;
  }
};

export const saveUserHeroes = async (heroes) => {
  try {
    const response = await fetch(`${BASE_URL}/users/${PRIVATE_ID}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ heroes }),
    });
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Erro ao gravar lista de super-heróis de um determinado utilizador:', error);
    throw error;
  }
};

export const saveUserTopHeroes = async (topHeroes) => {
  try {
    const response = await fetch(`${BASE_URL}/users/${PRIVATE_ID}/top`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ topHeroes }),
    });
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Erro ao gravar top da lista de super-heróis de um determinado utilizador:', error);
    throw error;
  }
};

export const updateHeroInDatabase = async (heroId, updatedHero) => {
    try {
      const response = await fetch(`${BASE_URL}/users/${PRIVATE_ID}/heroes/${heroId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updatedHero),
      });
  
      if (!response.ok) {
        throw new Error('Falha ao atualizar herói na base de dados');
      }
  
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Erro ao atualizar herói na base de dados:', error);
      throw error;
    }
  };
  
  export const deleteHeroFromDatabase = async (heroId) => {
    try {
      const response = await fetch(`${BASE_URL}/users/${PRIVATE_ID}/heroes/${heroId}`, {
        method: 'DELETE',
      });
  
      if (!response.ok) {
        throw new Error('Falha ao excluir herói na base de dados');
      }
  
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Erro ao excluir herói na base de dados:', error);
      throw error;
    }
  };

  export const toggleFavoriteHero = async (heroId, isFavorite) => {
    try {
      const response = await fetch(`${BASE_URL}/users/${PRIVATE_ID}/heroes/${heroId}/favorite`, {
        method: isFavorite ? 'DELETE' : 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
  
      if (!response.ok) {
        throw new Error(`Falha ao ${isFavorite ? 'remover' : 'adicionar'} herói aos favoritos na base de dados`);
      }
  
      const data = await response.json();
      return data;
    } catch (error) {
      console.error(`Erro ao ${isFavorite ? 'remover' : 'adicionar'} herói aos favoritos na base de dados:`, error);
      throw error;
    }
  };

