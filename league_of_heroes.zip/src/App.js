import './App.css';
import { Content } from './components/Content';
import { Footer } from './components/Footer';
import{Header} from './components/Header';
import React, { Component, useState } from 'react';
import{BrowserRouter} from 'react-router-dom';

function App (props){
  

  const [data, funcatualizardata] = useState({
    my_name: "Clementina Couto",
    project_name:"League of Heroes"
   });
   

  return (
    <div className="App">
      <BrowserRouter>
      <Header projeto={data.project_name} nome={data.my_name}></Header>
      <Content></Content>
      <Footer projeto={data.project_name} nome={data.my_name}></Footer>
      </BrowserRouter>
    </div>
  );

  
}

export default App;
