import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getUsers, getUserHeroes, getUserTopHeroes } from '../shared/api';

const Dashboard = ({ heroes }) => {
  const [heroesList, setHeroesList] = useState(heroes);
  const [favoritesList, setFavoritesList] = useState([]);
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const PUBLIC_ID = '14194';

  useEffect(() => {
    // Ao montar o componente, obtemos a lista de users
    const fetchUsers = async () => {
      try {
        const usersData = await getUsers();
        setUsers(usersData);
        // Definimos o primeiro user como selecionado por padrão
        if (usersData.length > 0) {
          setSelectedUser(usersData[0].id);
        }
      } catch (error) {
        console.error('Erro ao obter lista de usuários:', error);
      }
    };

    fetchUsers();
  }, []);

  useEffect(() => {
    // Quando o user selecionado mudar, obtemos os super-heróis e o top-3 desse user
    const fetchUserData = async () => {
      if (selectedUser) {
        try {
          const userHeroes = await getUserHeroes(selectedUser);
          setHeroesList(userHeroes);

          const userTopHeroes = await getUserTopHeroes(selectedUser);
          setFavoritesList(userTopHeroes);
        } catch (error) {
          console.error('Erro ao obter dados do usuário:', error);
        }
      }
    };

    fetchUserData();
  }, [selectedUser]);

  const removeHero = (heroToRemove) => {
    setHeroesList(heroesList.filter(hero => hero !== heroToRemove));
  };

  const toggleFavorite = (heroToToggle) => {
    if (favoritesList.includes(heroToToggle)) {
      setFavoritesList(favoritesList.filter(hero => hero !== heroToToggle));
    } else {
      setFavoritesList([...favoritesList, heroToToggle]);
    }
  };

  const handleUserChange = (e) => {
    setSelectedUser(e.target.value);
  };

  const isCurrentUser = selectedUser === PUBLIC_ID;

  return (
    <div className='Dashboard'>
      <h1>Dashboard</h1>
      <div>
        <label htmlFor="userDropdown">Utilizador Selecionado:</label>
        <select id="userDropdown" value={selectedUser} onChange={handleUserChange}>
          {users.map(user => (
            <option key={user.id} value={user.id}>{user.name}</option>
          ))}
        </select>
      </div>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Imagem</th>
            <th>Nome</th>
            <th>Superpoder</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          {heroesList.map((hero) => (
            <tr key={hero.id}>
              <td>{hero.id}</td>
              <td><img src={hero.image} alt={hero.name} /></td>
              <td>{hero.name}</td>
              <td>{hero.superpower ? hero.superpower : 'N/D'}</td>
              <td>
                <button onClick={() => removeHero(hero)} disabled={!isCurrentUser}>
                  Eliminar
                </button>
                <button onClick={() => toggleFavorite(hero)} disabled={!isCurrentUser}>
                  {favoritesList.includes(hero) ? 'Remover Favorito' : 'Adicionar Favorito'}
                </button>
                <Link to={`/dashboard/edit/${hero.id}`}>
                  <button disabled={!isCurrentUser}>Editar</button>
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Dashboard;
