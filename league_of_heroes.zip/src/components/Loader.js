import loader from '../Loader/XOsX.gif';
import './Loader.css';

export const Loader = (props) => {

    return (
        <div>
            <div className='loading'>
                <img src={loader} alt="Loading..." />
            </div>
        </div>

)};