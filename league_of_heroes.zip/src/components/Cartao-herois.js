import './Cartao-herois.css';

export const HeroInfo = (props) => {
    return (
        <div>
            <div className='cartao-super-heroi'>
                <fieldset>
                    <div>{props.nome}</div>
                    <img src={props.imagem} />
                </fieldset>
            </div>
        </div>
    );
}
