import './Footer.css';

export const Footer = (props) => {
    return (
        <div className='Footer'>{props.projeto} - Copyright © 2023 by {props.nome}.</div>
    );
}
