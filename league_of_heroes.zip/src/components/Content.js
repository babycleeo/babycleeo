import React, { useState, useEffect } from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import { HeroInfo } from './Cartao-herois';
import { Loader } from './Loader';
import Dashboard from './Dashboard';
import HeroForm from './HeroFrom';

export const Content = () => {
  const [listOfHeroes, setListOfHeroes] = useState([]);
  const [favoriteHeroes, setFavoritesList] = useState([2, 4, 1]);
  const [loading, setLoading] = useState(true);

  const handleFormSubmit = (heroData) => {
    if (heroData.id) {
      setListOfHeroes((prevHeroes) =>
        prevHeroes.map((hero) => (hero.id === heroData.id ? heroData : hero))
      );
    } else {
      setListOfHeroes((prevHeroes) => [...prevHeroes, { ...heroData, id: Date.now().toString() }]);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 3000);

    return () => clearTimeout(timer); // Limpa o timer se o componente for desmontado
  }, []);

  return (
    <Routes>
      <Route
        path="/"
        element={
          <>
            {loading ? <Loader /> : null}
            <h1>Top-3 Heróis</h1>
            <div className="grelha-superherois">
              {listOfHeroes
                .filter((hero) => favoriteHeroes.includes(hero.id))
                .map((hero) => (
                  <HeroInfo key={hero.id} nome={hero.name} imagem={hero.image} />
                ))}
            </div>
          </>
        }
      />
      <Route
        path="/dashboard"
        element={
          <>
            <Link to="/dashboard/add">Adicionar Super-Herói</Link>
            <Dashboard heroes={listOfHeroes} />
          </>
        }
      />
      <Route
        path="/dashboard/add"
        element={<HeroForm heroes={listOfHeroes} onSubmit={handleFormSubmit} />}
      />
      <Route
        path="/dashboard/edit/:id"
        element={<HeroForm heroes={listOfHeroes} onSubmit={handleFormSubmit} />}
      />
    </Routes>
  );
};
