import { Link } from 'react-router-dom';
import './Header.css';

export const Header = (props) => {
    return (
        <div className="Header">
            <h1>{props.projeto}</h1>
            <h3>desenvolvido por {props.nome}</h3>
            <nav>
                <div className='link-box'>
                    <Link to="/">Home</Link>
                    <Link to="/dashboard">Dashboard</Link>
                </div>
            </nav>    
        </div>
    );
}