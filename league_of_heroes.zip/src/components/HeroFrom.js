import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './HeroForm.css';

 
const HeroForm = ({ heroes, onSubmit }) => {
    const { id } = useParams();
    const navigate = useNavigate();
    console.log(heroes);
 
    const [heroData, setHeroData] = useState({
        nome: '',
        imagem: '',
        super_poder: ''
    });
 
    useEffect(() => {
        if (id) {
            const heroToEdit = heroes.find(hero => hero.id === id);
            if (heroToEdit) {
                setHeroData(heroToEdit);
            }
        }
    }, [id, heroes]);
 
    const handleChange = (event) => {
        setHeroData({
            ...heroData,
            [event.target.name]: event.target.value
        });
    };
 
    const handleSubmit = (event) => {
        event.preventDefault();
        onSubmit(heroData);
        navigate('/dashboard');
    };
 
    const handleBack = () => {
        navigate('/dashboard');
    };
 
    const title = id ? 'Editar Super-Herói' : 'Adicionar Super-Herói';
 
    return (
        <div className="hero-form">
            <h2>{title}</h2>
            <form onSubmit={handleSubmit}>
                <label className="hero-form-label">
                    Nome:
                    <input type="text" name="nome" value={heroData.nome} onChange={handleChange} />
                </label>
                <label className="hero-form-label">
                    Imagem:
                    <input type="text" name="imagem" value={heroData.imagem} onChange={handleChange} />
                </label>
                <label className="hero-form-label">
                    Super Poder:
                    <input type="text" name="super_poder" value={heroData.super_poder} onChange={handleChange} />
                </label>
                <input type="submit" value="Salvar" />
                <button type="button" onClick={handleBack}>Voltar</button>
            </form>
        </div>
    );
};
 
export default HeroForm;